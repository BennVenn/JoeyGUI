Please download GB/GBC/GBA box art thumbnails here: https://github.com/libretro/libretro-thumbnails and place them in this folder.

GB/C/A artwork is Approx ~6GB

